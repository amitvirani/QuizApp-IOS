//
//  ViewController.swift
//  Quiz App - Make your own quiz
//
//  Created by Amit Virani on 1/4/19.
//  Copyright © 2019 Amit Virani. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var currentQuestionLabel: UILabel!
    @IBOutlet weak var ScoreLabel: UILabel!
    @IBOutlet weak var progressBar: UIView!
    
    var allQuestions = QuestionBank()
    var questionNumber:Int = 0
    var score :Int = 0
    var totalQuestions: Int = 0
    var userAnswer:Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        nextQuestion()
        totalQuestions = allQuestions.list.count - 1
    }
    
    @IBAction func trueButton(_ sender: Any) {
        userAnswer = true
        checkAnswer()
        questionNumber += 1
        nextQuestion()
        
    }
    
    @IBAction func falseButton(_ sender: Any) {
        userAnswer = false
        checkAnswer()
        questionNumber += 1
        nextQuestion()
        
    }
    
    func updateUI(){
        ScoreLabel.text = "Score: \(score)"
        currentQuestionLabel.text = "\(questionNumber + 1) / \(totalQuestions + 1)"
       
        progressBar.frame.size.width = (view.frame.size.width / 13) * CGFloat(questionNumber + 1)
    }
    func nextQuestion(){
        if questionNumber <= totalQuestions{
            
            questionLabel.text = allQuestions.list[questionNumber].question
            
        }
        else {
            let alert = UIAlertController(title: "Great!", message: "You have completed all the Questions. Ready for one more time ??", preferredStyle: .alert)
            let restartAction = UIAlertAction(title: "Restart", style: .default) { (UIAlertAction) in
                self.restartQuiz()}
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (UIAlertAction) in
                self.goToNextViewController()
            }
            alert.addAction(restartAction)
            alert.addAction(cancelAction)
            present(alert, animated: true, completion: nil)

        }
        
    }
    
    func checkAnswer() {
        if questionNumber <= totalQuestions {
        if userAnswer == allQuestions.list[questionNumber].answer {
            score += 1
            
            ProgressHUD.showSuccess("Correct")
        } else {
            
            ProgressHUD.showError("Wrong!")
        }
        updateUI()
        }
    }
    
    func restartQuiz() {
        questionNumber = 0
        score = 0
        updateUI()
        nextQuestion()
    }
    func goToNextViewController() {
        
    }

}

