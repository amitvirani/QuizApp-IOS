//
//  Question.swift
//  Quiz App - Make your own quiz
//
//  Created by Amit Virani on 1/4/19.
//  Copyright © 2019 Amit Virani. All rights reserved.
//

import Foundation
class Question {
    
    var question:String
    var answer:Bool
    
    init (text:String, correctAnswer:Bool){
        question = text
        answer = correctAnswer
    }
}
